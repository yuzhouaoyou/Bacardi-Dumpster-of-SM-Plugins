# FixHintColorMessages

Hotfix for use colors on hint messeges again in csgo
